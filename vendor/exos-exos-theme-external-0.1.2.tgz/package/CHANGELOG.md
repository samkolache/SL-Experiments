# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

# [0.1.2] - 2026-03-10
-  Updated the required-field border color for both error and non-error states within the fc-white-background class.

# [0.1.1] - 2026-02-26
-  Implemented updated disabled and read‑only styles for Input, Select, DatePicker, and Button Group element. These styles apply specifically when the components are rendered with the fc-white-background class.


## [0.1.0] - 2026-01-09
### Copied
- Copied from exos-theme-alpaca.

### Newly Added
- Created New theme called Exos-theme-external
- New Accordion is been added under Navigation & Accordion Section
- New HTML 5 Dialog is been added Under Modals Section along with boostrap 5 Modal and _fluid-dialog.scss which is used for HTML5 Dialog added under scss in ExosThemeExternal
- New color is been added under Color Section
- New scss file root-new-theme and _variable-new-theme added 

### Modified
- Typography, Input, Button, Card, Tags, Navigation, Modals and Notification updated as per New External Design System
 

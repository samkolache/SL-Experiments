# ExosThemeExternal

This project contains the `exos-theme-external` package.

## How to Use

- Either:
  - Run `npm install exos-theme-external` in your project, OR
  - Add `exos-theme-external` to your project's `package.json` file.
- Import stylesheets into your project's main stylesheet as noted below.
  - Examples:
    - Complete SCSS Package: `@import "@exos/exos-theme-external/src/main";`

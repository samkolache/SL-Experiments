function disabledElements() {
  document.addEventListener("DOMContentLoaded", function() {
    const disableElements = document.querySelectorAll("details[disabled]");
    disableElements.forEach((disabledElement) => {
      disabledElement.setAttribute("tabindex", "-1");
      disabledElement.addEventListener("click", function(event) {
        event.preventDefault();
      });
    });
  });
}


function openOnlyOneAccordion(selector) {
  const accordionClicked = event => {
    let target = event.target;
    target = target.closest('summary');
    if (!target) return;
    const currentDetails = target.parentElement;
    const accordion = currentDetails.closest(selector);
    const allOpenDetails = accordion.querySelectorAll('details[regular][open]');
    for (const details of allOpenDetails) {
      if (details === currentDetails) continue;
      details.removeAttribute('open');
    }
  };
  let accordions = document.querySelectorAll(selector);
  accordions.forEach((accordion) => {
    if ((accordion).hasAttribute('multiple')) {
      return;
    } else if ((accordion).hasAttribute('single')) {
      accordion.addEventListener('click', accordionClicked);
    } else return;
  });
}


function calculateScroll() {
  window.addEventListener('scroll', () => {
    const denominator = document.documentElement.scrollHeight - window.innerHeight;
    const scrollValue = denominator === 0 ? 0 : window.scrollY / denominator;
    document.body.style.setProperty('--scroll', scrollValue.toString());
  }, false);
}

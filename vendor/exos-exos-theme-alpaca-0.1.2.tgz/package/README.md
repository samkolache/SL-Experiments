# ExosThemeAlpaca

This project contains the `exos-theme-alpaca` package.

## How to Use

- Either:
  - Run `npm install exos-theme-alpaca` in your project, OR
  - Add `exos-theme-alpaca` to your project's `package.json` file.
- Import stylesheets into your project's main stylesheet as noted below.
  - Examples:
    - Complete SCSS Package: `@import "@exos/exos-theme-alpaca/src/main";`

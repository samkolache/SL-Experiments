# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.2]- 2025-06-10
## Modified
- Modified bootstrap import path 
## [0.1.1]- 2024-10-02
## Added
- Added support for icon-document-checklist.
## [0.1.0]- 2024-01-25
- Published stable version.
## [0.3.0-alpha]- 2024-01-22
### Added
- Added support for the Notification feature.
### Fixed
- Fixed some layout issues for the Pagination, Modals, and Navigation features.
## [0.2.1-alpha]- 2024-01-15
### Modified
- Modified icomoon font file imports to use relative paths.
## [0.2.0-alpha]- 2024-01-15
### Modified
- Modified import statements to fix build errors.
## [0.1.0-alpha]- 2024-01-12
### Added
- Added support for Bootstrap 5.3.
## [0.0.0] - 2024-01-12
### Copied
- Copied from exos-theme.
